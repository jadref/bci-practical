import sys
sys.path.append('../../python/signalProc')
import pickle

import bufhelp
import preproc
import linear

if __name__ == '__main__':
    f = pickle.load(open('training_data.pkl', 'rb'))
    data = f['data']
    events = f['events']
    hdr = f['hdr']

    data = preproc.detrend(data)
    data, _ = preproc.badchannelremoval(data)

    # this line causes memory errors
    # data is of shape (1300, 60, 4)
    # spatial filtering tries to create eye(78_000)
    # data = preproc.spatialfilter(data)

    data = preproc.spectralfilter(data, (0, 0, 15, 15),
                                  hdr.fSample)
    data, events, _ = preproc.badtrailremoval(data, events)
    classifier = linear.fit(data, events)
    pickle.dump(classifier, open('classifier.pkl', 'wb'))
